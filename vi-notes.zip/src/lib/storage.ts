export interface KeystrokeData {
  key: string;
  pressTime: number;
  releaseTime: number;
}

export interface PasteEvent {
  timestamp: number;
  textLength: number;
}

export interface WritingSession {
  id: string;
  userId: string;
  text: string;
  keystrokes: KeystrokeData[];
  pastedTextEvents: PasteEvent[];
  analysisResult: {
    confidenceScore: number;
    summary: string;
    suspiciousPatterns: string[];
  };
  createdAt: string;
}

export interface User {
  uid: string;
  email: string;
  displayName: string;
  isAnonymous: boolean;
}

const SESSIONS_KEY = 'vinotes_sessions';
const USER_KEY = 'vinotes_user';

export const storage = {
  getSessions: (userId: string): WritingSession[] => {
    const data = localStorage.getItem(SESSIONS_KEY);
    if (!data) return [];
    const allSessions: WritingSession[] = JSON.parse(data);
    return allSessions.filter(s => s.userId === userId).sort((a, b) => 
      new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
  },

  saveSession: (session: WritingSession) => {
    const data = localStorage.getItem(SESSIONS_KEY);
    const allSessions: WritingSession[] = data ? JSON.parse(data) : [];
    allSessions.push(session);
    localStorage.setItem(SESSIONS_KEY, JSON.stringify(allSessions));
  },

  deleteSession: (sessionId: string) => {
    const data = localStorage.getItem(SESSIONS_KEY);
    if (!data) return;
    const allSessions: WritingSession[] = JSON.parse(data);
    const filtered = allSessions.filter(s => s.id !== sessionId);
    localStorage.setItem(SESSIONS_KEY, JSON.stringify(filtered));
  },

  getUser: (): User | null => {
    const data = localStorage.getItem(USER_KEY);
    return data ? JSON.parse(data) : null;
  },

  setUser: (user: User | null) => {
    if (user) {
      localStorage.setItem(USER_KEY, JSON.stringify(user));
    } else {
      localStorage.removeItem(USER_KEY);
    }
  }
};
