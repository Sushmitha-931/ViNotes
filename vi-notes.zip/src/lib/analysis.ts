import { GoogleGenAI, Type } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

export interface KeystrokeData {
  key: string;
  pressTime: number;
  releaseTime: number;
}

export interface PasteEvent {
  timestamp: number;
  textLength: number;
}

export interface AnalysisResult {
  confidenceScore: number;
  summary: string;
  suspiciousPatterns: string[];
}

export async function analyzeAuthenticity(
  text: string,
  keystrokes: KeystrokeData[],
  pastedTextEvents: PasteEvent[]
): Promise<AnalysisResult> {
  // Prepare a summary of the keystroke data to avoid sending too much data
  // We'll calculate some basic stats to help the model
  const totalKeystrokes = keystrokes.length;
  const totalPasteLength = pastedTextEvents.reduce((acc, event) => acc + event.textLength, 0);
  
  // Calculate average typing speed (characters per minute)
  let avgCpm = 0;
  if (keystrokes.length > 1) {
    const startTime = keystrokes[0].pressTime;
    const endTime = keystrokes[keystrokes.length - 1].releaseTime;
    const durationMinutes = (endTime - startTime) / 60000;
    avgCpm = durationMinutes > 0 ? totalKeystrokes / durationMinutes : 0;
  }

  // Identify large pauses
  const pauses: number[] = [];
  for (let i = 1; i < keystrokes.length; i++) {
    const pause = keystrokes[i].pressTime - keystrokes[i - 1].releaseTime;
    if (pause > 2000) { // Pauses longer than 2 seconds
      pauses.push(pause);
    }
  }

  const prompt = `
    Analyze the following writing session data for authenticity. 
    Determine if the text was likely written by a human in real-time or if it shows signs of AI generation or copy-pasting.

    Text Content:
    "${text.substring(0, 5000)}" // Limit text for prompt

    Writing Metadata:
    - Total Keystrokes: ${totalKeystrokes}
    - Total Characters Pasted: ${totalPasteLength}
    - Average Typing Speed (CPM): ${avgCpm.toFixed(2)}
    - Number of significant pauses (>2s): ${pauses.length}
    - Paste Events: ${JSON.stringify(pastedTextEvents)}

    Consider:
    1. Does the typing speed match the text complexity?
    2. Are there suspicious paste events (large chunks of text appearing instantly)?
    3. Does the linguistic structure of the text match the observed typing rhythm (e.g., pauses at punctuation)?
    4. AI-generated text often has uniform sentence lengths and vocabulary distribution.

    Return the result in JSON format.
  `;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3.1-pro-preview",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            confidenceScore: {
              type: Type.NUMBER,
              description: "A score from 0 to 100 representing the confidence that the text is human-written."
            },
            summary: {
              type: Type.STRING,
              description: "A brief summary of the authenticity analysis."
            },
            suspiciousPatterns: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
              description: "A list of specific patterns that suggest AI involvement or non-human behavior."
            }
          },
          required: ["confidenceScore", "summary", "suspiciousPatterns"]
        }
      }
    });

    const result = JSON.parse(response.text || "{}");
    return {
      confidenceScore: result.confidenceScore ?? 50,
      summary: result.summary ?? "Analysis failed to generate a summary.",
      suspiciousPatterns: result.suspiciousPatterns ?? []
    };
  } catch (error) {
    console.error("Analysis error:", error);
    return {
      confidenceScore: 0,
      summary: "An error occurred during authenticity analysis.",
      suspiciousPatterns: ["Analysis error"]
    };
  }
}
