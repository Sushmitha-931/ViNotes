import React, { useState, useEffect } from 'react';
import { storage, User } from './lib/storage';
import { Toaster } from 'sonner';
import { motion, AnimatePresence } from 'motion/react';
import { ShieldCheck, PenTool, LayoutDashboard, FileText, Menu, X, Info } from 'lucide-react';
import Auth from './components/Auth';
import Editor from './components/Editor';
import Dashboard from './components/Dashboard';
import Report from './components/Report';
import HowItWorks from './components/HowItWorks';

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [view, setView] = useState<'dashboard' | 'editor' | 'report' | 'how-it-works'>('dashboard');
  const [selectedSession, setSelectedSession] = useState<any>(null);
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  useEffect(() => {
    const storedUser = storage.getUser();
    setUser(storedUser);
    setLoading(false);
  }, []);

  const handleAuthChange = () => {
    const storedUser = storage.getUser();
    setUser(storedUser);
  };

  const handleSessionSaved = () => {
    setView('dashboard');
  };

  const handleSelectSession = (session: any) => {
    setSelectedSession(session);
    setView('report');
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-[#F5F5F0] flex items-center justify-center">
        <div className="w-12 h-12 border-4 border-ink border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-[#F5F5F0] flex items-center justify-center p-4">
        <Auth user={user} onAuthChange={handleAuthChange} />
        <Toaster position="top-center" richColors />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#F5F5F0] text-ink font-sans selection:bg-ink/10">
      <Toaster position="top-center" richColors />
      
      {/* Navigation */}
      <nav className="sticky top-0 z-50 bg-[#F5F5F0]/80 backdrop-blur-xl border-b border-ink/5">
        <div className="max-w-7xl mx-auto px-6 h-20 flex items-center justify-between">
          <div className="flex items-center gap-3 group cursor-pointer" onClick={() => setView('dashboard')}>
            <div className="w-10 h-10 bg-ink rounded-xl flex items-center justify-center group-hover:scale-105 transition-transform">
              <ShieldCheck className="w-6 h-6 text-white" />
            </div>
            <h1 className="text-2xl font-serif italic tracking-tight">Vi-Notes</h1>
          </div>

          <div className="hidden md:flex items-center gap-8">
            <button
              onClick={() => setView('dashboard')}
              className={`flex items-center gap-2 text-sm font-bold uppercase tracking-widest transition-colors ${
                view === 'dashboard' ? 'text-ink' : 'text-ink/40 hover:text-ink'
              }`}
            >
              <LayoutDashboard className="w-4 h-4" />
              Dashboard
            </button>
            <button
              onClick={() => setView('editor')}
              className={`flex items-center gap-2 text-sm font-bold uppercase tracking-widest transition-colors ${
                view === 'editor' ? 'text-ink' : 'text-ink/40 hover:text-ink'
              }`}
            >
              <PenTool className="w-4 h-4" />
              Write
            </button>
            <button
              onClick={() => setView('how-it-works')}
              className={`flex items-center gap-2 text-sm font-bold uppercase tracking-widest transition-colors ${
                view === 'how-it-works' ? 'text-ink' : 'text-ink/40 hover:text-ink'
              }`}
            >
              <Info className="w-4 h-4" />
              Overview
            </button>
            <div className="w-px h-6 bg-ink/10 mx-2" />
            <Auth user={user} onAuthChange={() => {}} />
          </div>

          <button className="md:hidden p-2" onClick={() => setIsMenuOpen(!isMenuOpen)}>
            {isMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </nav>

      {/* Mobile Menu */}
      <AnimatePresence>
        {isMenuOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="md:hidden bg-white border-b border-ink/10 overflow-hidden"
          >
            <div className="p-6 space-y-6">
              <button
                onClick={() => { setView('dashboard'); setIsMenuOpen(false); }}
                className="flex items-center gap-3 w-full text-lg font-medium"
              >
                <LayoutDashboard className="w-5 h-5" /> Dashboard
              </button>
              <button
                onClick={() => { setView('editor'); setIsMenuOpen(false); }}
                className="flex items-center gap-3 w-full text-lg font-medium"
              >
                <PenTool className="w-5 h-5" /> Write
              </button>
              <button
                onClick={() => { setView('how-it-works'); setIsMenuOpen(false); }}
                className="flex items-center gap-3 w-full text-lg font-medium"
              >
                <Info className="w-5 h-5" /> Overview
              </button>
              <div className="pt-6 border-t border-ink/5">
                <Auth user={user} onAuthChange={() => {}} />
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-6 py-12">
        <AnimatePresence mode="wait">
          {view === 'dashboard' && (
            <motion.div
              key="dashboard"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
            >
              <div className="flex items-center justify-between mb-12">
                <div>
                  <h2 className="text-4xl font-serif italic mb-2">Your Writing Library</h2>
                  <p className="text-ink/60">Manage and verify your human authorship records.</p>
                </div>
                <div className="flex items-center gap-4">
                  <button
                    onClick={() => setView('how-it-works')}
                    className="px-6 py-4 bg-ink/5 text-ink rounded-2xl font-bold uppercase tracking-widest hover:bg-ink/10 transition-all"
                  >
                    Project Info
                  </button>
                  <button
                    onClick={() => setView('editor')}
                    className="flex items-center gap-3 px-8 py-4 bg-ink text-white rounded-2xl font-bold uppercase tracking-widest hover:bg-ink/90 transition-all hover:scale-[1.02] active:scale-[0.98]"
                  >
                    <PenTool className="w-5 h-5" />
                    New Session
                  </button>
                </div>
              </div>
              <Dashboard user={user} onSelectSession={handleSelectSession} />
            </motion.div>
          )}

          {view === 'editor' && (
            <motion.div
              key="editor"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
            >
              <div className="mb-12 text-center">
                <h2 className="text-4xl font-serif italic mb-2">Write Freely</h2>
                <p className="text-ink/60">Our system monitors your rhythm in the background.</p>
              </div>
              <Editor user={user} onSessionSaved={handleSessionSaved} />
            </motion.div>
          )}

          {view === 'report' && selectedSession && (
            <motion.div
              key="report"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
            >
              <Report session={selectedSession} onBack={() => setView('dashboard')} />
            </motion.div>
          )}

          {view === 'how-it-works' && (
            <motion.div
              key="how-it-works"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
            >
              <HowItWorks />
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      {/* Footer */}
      <footer className="max-w-7xl mx-auto px-6 py-12 border-t border-ink/5 text-center">
        <div className="flex items-center justify-center gap-2 mb-4">
          <ShieldCheck className="w-5 h-5 text-ink/20" />
          <span className="text-xs font-bold uppercase tracking-widest text-ink/20">Vi-Notes Authenticity Protocol v1.0</span>
        </div>
        <p className="text-xs text-ink/40 max-w-md mx-auto leading-relaxed">
          Vi-Notes uses advanced behavioral biometrics and linguistic analysis to ensure the integrity of human-written content in the age of AI.
        </p>
      </footer>
    </div>
  );
}
