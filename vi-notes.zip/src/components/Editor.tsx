import React, { useState, useRef, useEffect } from 'react';
import { storage, WritingSession } from '../lib/storage';
import { toast } from 'sonner';
import { Save, Loader2, ShieldCheck, AlertCircle, Clock, Type as TypeIcon, FileText, Activity } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { analyzeAuthenticity, KeystrokeData, PasteEvent } from '../lib/analysis';

export default function Editor({ user, onSessionSaved }: { user: any, onSessionSaved: () => void }) {
  const [text, setText] = useState('');
  const [keystrokes, setKeystrokes] = useState<KeystrokeData[]>([]);
  const [pastedTextEvents, setPastedTextEvents] = useState<PasteEvent[]>([]);
  const [saving, setSaving] = useState(false);
  const [analyzing, setAnalyzing] = useState(false);
  const [analysisResult, setAnalysisResult] = useState<any>(null);
  const [showReport, setShowReport] = useState(false);

  const keyPressTimes = useRef<{ [key: string]: number }>({});

  const handleKeyDown = (e: React.KeyboardEvent) => {
    const key = e.key;
    if (!keyPressTimes.current[key]) {
      keyPressTimes.current[key] = Date.now();
    }
  };

  const handleKeyUp = (e: React.KeyboardEvent) => {
    const key = e.key;
    const pressTime = keyPressTimes.current[key];
    if (pressTime) {
      const releaseTime = Date.now();
      setKeystrokes(prev => [...prev, { key, pressTime, releaseTime }]);
      delete keyPressTimes.current[key];
    }
  };

  const handlePaste = (e: React.ClipboardEvent) => {
    const pastedText = e.clipboardData.getData('text');
    setPastedTextEvents(prev => [...prev, {
      timestamp: Date.now(),
      textLength: pastedText.length
    }]);
    toast.info('Pasted text detected and recorded.');
  };

  const handleSave = async () => {
    if (!text.trim()) {
      toast.error('Please write something before saving.');
      return;
    }

    setSaving(true);
    setAnalyzing(true);
    try {
      // Analyze with Gemini
      const analysis = await analyzeAuthenticity(text, keystrokes, pastedTextEvents);
      setAnalysisResult(analysis);

      // Save to Local Storage
      const sessionData: WritingSession = {
        userId: user.uid,
        text,
        keystrokes,
        pastedTextEvents,
        analysisResult: analysis,
        createdAt: new Date().toISOString(),
        id: crypto.randomUUID()
      };

      storage.saveSession(sessionData);
      
      toast.success('Session saved and analyzed successfully!');
      setShowReport(true);
      onSessionSaved();
    } catch (error) {
      console.error('Save error:', error);
      toast.error('Failed to save session.');
    } finally {
      setSaving(false);
      setAnalyzing(false);
    }
  };

  const stats = {
    wordCount: text.trim() ? text.trim().split(/\s+/).length : 0,
    charCount: text.length,
    keystrokeCount: keystrokes.length,
    pasteCount: pastedTextEvents.length
  };

  if (showReport && analysisResult) {
    return (
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="max-w-3xl mx-auto p-8 bg-white rounded-2xl shadow-sm border border-ink/10"
      >
        <div className="flex items-center justify-between mb-8">
          <h2 className="text-2xl font-serif italic text-ink">Authenticity Report</h2>
          <div className={`px-4 py-2 rounded-full font-bold text-sm ${
            analysisResult.confidenceScore > 80 ? 'bg-green-100 text-green-700' :
            analysisResult.confidenceScore > 50 ? 'bg-yellow-100 text-yellow-700' :
            'bg-red-100 text-red-700'
          }`}>
            {analysisResult.confidenceScore}% Human Confidence
          </div>
        </div>

        <div className="space-y-6">
          <div className="p-6 bg-ink/5 rounded-xl border border-ink/10">
            <h3 className="text-sm font-bold uppercase tracking-wider text-ink/60 mb-2">Analysis Summary</h3>
            <p className="text-ink leading-relaxed">{analysisResult.summary}</p>
          </div>

          {analysisResult.suspiciousPatterns.length > 0 && (
            <div>
              <h3 className="text-sm font-bold uppercase tracking-wider text-ink/60 mb-3">Suspicious Patterns</h3>
              <ul className="space-y-2">
                {analysisResult.suspiciousPatterns.map((pattern: string, i: number) => (
                  <li key={i} className="flex items-start gap-3 p-3 bg-red-50 rounded-lg border border-red-100 text-red-700 text-sm">
                    <AlertCircle className="w-4 h-4 mt-0.5 flex-shrink-0" />
                    {pattern}
                  </li>
                ))}
              </ul>
            </div>
          )}

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            <div className="p-4 bg-white border border-ink/10 rounded-xl">
              <div className="text-xs text-ink/40 uppercase font-bold mb-1">Words</div>
              <div className="text-xl font-mono text-ink">{stats.wordCount}</div>
            </div>
            <div className="p-4 bg-white border border-ink/10 rounded-xl">
              <div className="text-xs text-ink/40 uppercase font-bold mb-1">Keystrokes</div>
              <div className="text-xl font-mono text-ink">{stats.keystrokeCount}</div>
            </div>
            <div className="p-4 bg-white border border-ink/10 rounded-xl">
              <div className="text-xs text-ink/40 uppercase font-bold mb-1">Pastes</div>
              <div className="text-xl font-mono text-ink">{stats.pasteCount}</div>
            </div>
            <div className="p-4 bg-white border border-ink/10 rounded-xl">
              <div className="text-xs text-ink/40 uppercase font-bold mb-1">Confidence</div>
              <div className="text-xl font-mono text-ink">{analysisResult.confidenceScore}%</div>
            </div>
          </div>

          <div className="pt-6 border-t border-ink/10 flex justify-end">
            <button
              onClick={() => setShowReport(false)}
              className="px-6 py-2 bg-ink text-white rounded-xl font-medium hover:bg-ink/90 transition-all"
            >
              Back to Editor
            </button>
          </div>
        </div>
      </motion.div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto space-y-8">
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
        <div className="lg:col-span-3 space-y-6">
          <div className="relative group">
            <textarea
              value={text}
              onChange={(e) => setText(e.target.value)}
              onKeyDown={handleKeyDown}
              onKeyUp={handleKeyUp}
              onPaste={handlePaste}
              placeholder="Start writing freely here..."
              className="w-full h-[60vh] p-12 bg-white rounded-[2.5rem] border border-ink/10 shadow-sm focus:ring-4 focus:ring-ink/5 focus:border-ink/20 outline-none resize-none text-xl leading-relaxed font-serif placeholder:text-ink/20 transition-all"
            />
            <div className="absolute top-8 right-8 flex items-center gap-2 px-4 py-2 bg-ink/5 rounded-full border border-ink/10 backdrop-blur-sm">
              <ShieldCheck className="w-4 h-4 text-ink/40" />
              <span className="text-[10px] uppercase font-bold tracking-widest text-ink/40">Monitoring Active</span>
            </div>
          </div>

          <div className="flex items-center justify-between bg-white p-6 rounded-3xl border border-ink/10 shadow-sm">
            <div className="flex items-center gap-8">
              <div className="flex items-center gap-3 text-ink/60">
                <div className="w-8 h-8 bg-ink/5 rounded-lg flex items-center justify-center">
                  <FileText className="w-4 h-4" />
                </div>
                <div className="flex flex-col">
                  <span className="text-[10px] uppercase font-bold tracking-widest text-ink/40">Words</span>
                  <span className="text-sm font-mono font-bold">{stats.wordCount}</span>
                </div>
              </div>
              <div className="flex items-center gap-3 text-ink/60">
                <div className="w-8 h-8 bg-ink/5 rounded-lg flex items-center justify-center">
                  <Clock className="w-4 h-4" />
                </div>
                <div className="flex flex-col">
                  <span className="text-[10px] uppercase font-bold tracking-widest text-ink/40">Keystrokes</span>
                  <span className="text-sm font-mono font-bold">{stats.keystrokeCount}</span>
                </div>
              </div>
            </div>
            
            <button
              onClick={handleSave}
              disabled={saving || analyzing || !text.trim()}
              className="flex items-center gap-3 px-10 py-4 bg-ink text-white rounded-2xl font-bold uppercase tracking-widest hover:bg-ink/90 transition-all disabled:opacity-50 hover:scale-[1.02] active:scale-[0.98] shadow-lg shadow-ink/10"
            >
              {saving || analyzing ? (
                <>
                  <Loader2 className="w-5 h-5 animate-spin" />
                  {analyzing ? 'Analyzing...' : 'Saving...'}
                </>
              ) : (
                <>
                  <ShieldCheck className="w-5 h-5" />
                  Verify & Save
                </>
              )}
            </button>
          </div>
        </div>

        <div className="space-y-6">
          <div className="bg-white p-6 rounded-3xl border border-ink/10 shadow-sm">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-[10px] font-bold uppercase tracking-widest text-ink/40">Live Data Stream</h3>
              <Activity className="w-3 h-3 text-ink/20 animate-pulse" />
            </div>
            <div className="h-[400px] overflow-hidden relative">
              <div className="absolute inset-0 bg-gradient-to-b from-white via-transparent to-white z-10 pointer-events-none" />
              <div className="space-y-2 font-mono text-[10px] text-ink/40">
                <AnimatePresence initial={false}>
                  {[...keystrokes].reverse().slice(0, 15).map((ks, i) => (
                    <motion.div
                      key={`${ks.pressTime}-${i}`}
                      initial={{ opacity: 0, x: -10 }}
                      animate={{ opacity: 1, x: 0 }}
                      className="flex items-center justify-between p-3 bg-ink/[0.02] rounded-xl border border-ink/5"
                    >
                      <span className="text-ink font-bold px-2 py-1 bg-ink/5 rounded-md">
                        {ks.key === ' ' ? 'SPACE' : ks.key.length > 1 ? ks.key.toUpperCase() : ks.key}
                      </span>
                      <span className="tabular-nums">{ks.releaseTime - ks.pressTime}ms</span>
                    </motion.div>
                  ))}
                </AnimatePresence>
                {keystrokes.length === 0 && (
                  <div className="h-full flex flex-col items-center justify-center text-center p-4 opacity-40">
                    <Activity className="w-8 h-8 mb-4 animate-pulse" />
                    <p className="text-[10px] font-bold uppercase tracking-widest">Waiting for input...</p>
                  </div>
                )}
              </div>
            </div>
          </div>

          <div className="bg-ink p-6 rounded-3xl border border-white/10 shadow-xl text-white">
            <h3 className="text-[10px] font-bold uppercase tracking-widest text-white/40 mb-4">System Status</h3>
            <div className="space-y-4">
              <div className="flex items-center gap-3">
                <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse shadow-[0_0_8px_rgba(34,197,94,0.6)]" />
                <span className="text-[10px] font-bold uppercase tracking-widest text-white/80">Biometric Active</span>
              </div>
              <div className="flex items-center gap-3">
                <div className="w-2 h-2 bg-blue-500 rounded-full animate-pulse shadow-[0_0_8px_rgba(59,130,246,0.6)]" />
                <span className="text-[10px] font-bold uppercase tracking-widest text-white/80">Linguistic Engine</span>
              </div>
              <div className="flex items-center gap-3">
                <div className="w-2 h-2 bg-purple-500 rounded-full animate-pulse shadow-[0_0_8px_rgba(168,85,247,0.6)]" />
                <span className="text-[10px] font-bold uppercase tracking-widest text-white/80">Pattern Matching</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="flex items-center justify-center gap-12 py-4">
        <div className="flex items-center gap-3 text-ink/30">
          <TypeIcon className="w-4 h-4" />
          <span className="text-[10px] font-bold uppercase tracking-widest">Natural Rhythm</span>
        </div>
        <div className="flex items-center gap-3 text-ink/30">
          <ShieldCheck className="w-4 h-4" />
          <span className="text-[10px] font-bold uppercase tracking-widest">Pattern Detection</span>
        </div>
        <div className="flex items-center gap-3 text-ink/30">
          <AlertCircle className="w-4 h-4" />
          <span className="text-[10px] font-bold uppercase tracking-widest">Paste Tracking</span>
        </div>
      </div>
    </div>
  );
}
