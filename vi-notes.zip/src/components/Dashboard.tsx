import React, { useState, useEffect } from 'react';
import { storage, WritingSession } from '../lib/storage';
import { toast } from 'sonner';
import { FileText, Trash2, ChevronRight, ShieldCheck, AlertCircle, Clock, Calendar } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export default function Dashboard({ user, onSelectSession }: { user: any, onSelectSession: (session: any) => void }) {
  const [sessions, setSessions] = useState<WritingSession[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (user) {
      const data = storage.getSessions(user.uid);
      setSessions(data);
      setLoading(false);
    }
  }, [user]);

  const handleDelete = (e: React.MouseEvent, sessionId: string) => {
    e.stopPropagation();
    if (window.confirm('Are you sure you want to delete this session?')) {
      storage.deleteSession(sessionId);
      setSessions(prev => prev.filter(s => s.id !== sessionId));
      toast.success('Session deleted.');
    }
  };

  const handleDemoSession = async () => {
    const demoSession: WritingSession = {
      userId: user.uid,
      text: "This is a sample text written to demonstrate the authenticity verification features of Vi-Notes. Notice how the system captures the rhythm of my typing, including the pauses between words and the speed of individual keystrokes.",
      keystrokes: Array.from({ length: 150 }, (_, i) => ({
        key: 'abcde '[Math.floor(Math.random() * 6)],
        pressTime: Date.now() - (150 - i) * 200,
        releaseTime: Date.now() - (150 - i) * 200 + 80
      })),
      pastedTextEvents: [],
      analysisResult: {
        confidenceScore: 98,
        summary: "The typing rhythm shows highly natural variance consistent with human cognitive processing. No robotic patterns or bulk text injections were detected.",
        suspiciousPatterns: []
      },
      createdAt: new Date().toISOString(),
      id: crypto.randomUUID()
    };

    storage.saveSession(demoSession);
    setSessions(prev => [demoSession, ...prev]);
    toast.success('Demo session added to your library!');
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <div className="w-8 h-8 border-4 border-ink border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  if (sessions.length === 0) {
    return (
      <div className="text-center py-20 bg-white rounded-3xl border border-ink/10 shadow-sm">
        <div className="w-16 h-16 bg-ink/5 rounded-2xl flex items-center justify-center mx-auto mb-6">
          <FileText className="w-8 h-8 text-ink/20" />
        </div>
        <h3 className="text-xl font-serif italic text-ink mb-2">No writing sessions yet</h3>
        <p className="text-ink/60 max-w-xs mx-auto mb-8">
          Start your first writing session to verify your authenticity.
        </p>
        <button
          onClick={handleDemoSession}
          className="px-8 py-4 bg-ink/5 text-ink rounded-2xl font-bold uppercase tracking-widest hover:bg-ink/10 transition-all"
        >
          Try Demo Session
        </button>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <h2 className="text-sm font-bold uppercase tracking-widest text-ink/40 mb-6">Recent Sessions</h2>
      <div className="grid gap-4">
        <AnimatePresence mode="popLayout">
          {sessions.map((session) => (
            <motion.div
              key={session.id}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 20 }}
              onClick={() => onSelectSession(session)}
              className="group flex items-center justify-between p-6 bg-white rounded-2xl border border-ink/10 shadow-sm hover:border-ink/20 hover:shadow-md transition-all cursor-pointer"
            >
              <div className="flex items-center gap-6">
                <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${
                  session.analysisResult?.confidenceScore > 80 ? 'bg-green-50 text-green-600' :
                  session.analysisResult?.confidenceScore > 50 ? 'bg-yellow-50 text-yellow-600' :
                  'bg-red-50 text-red-600'
                }`}>
                  <ShieldCheck className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="font-medium text-ink mb-1 line-clamp-1 max-w-md">
                    {session.text.substring(0, 60)}...
                  </h3>
                  <div className="flex items-center gap-4 text-xs text-ink/40 font-mono">
                    <span className="flex items-center gap-1">
                      <Calendar className="w-3 h-3" />
                      {new Date(session.createdAt).toLocaleDateString()}
                    </span>
                    <span className="flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      {session.keystrokes?.length || 0} keys
                    </span>
                    <span className="flex items-center gap-1">
                      <ShieldCheck className="w-3 h-3" />
                      {session.analysisResult?.confidenceScore}% human
                    </span>
                  </div>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={(e) => handleDelete(e, session.id)}
                  className="p-2 rounded-lg hover:bg-red-50 text-ink/20 hover:text-red-500 transition-colors opacity-0 group-hover:opacity-100"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
                <ChevronRight className="w-5 h-5 text-ink/20 group-hover:text-ink/40 transition-colors" />
              </div>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>
    </div>
  );
}
