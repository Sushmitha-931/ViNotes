import React from 'react';
import { FileText, ShieldCheck, AlertCircle, Clock, Calendar, ChevronLeft, Type, MousePointer, Activity } from 'lucide-react';
import { motion } from 'motion/react';

export default function Report({ session, onBack }: { session: any, onBack: () => void }) {
  const { analysisResult, text, keystrokes, pastedTextEvents, createdAt } = session;
  
  const stats = {
    wordCount: text.trim() ? text.trim().split(/\s+/).length : 0,
    charCount: text.length,
    keystrokeCount: keystrokes?.length || 0,
    pasteCount: pastedTextEvents?.length || 0,
    avgSpeed: 0
  };

  if (keystrokes?.length > 1) {
    const startTime = keystrokes[0].pressTime;
    const endTime = keystrokes[keystrokes.length - 1].releaseTime;
    const durationMinutes = (endTime - startTime) / 60000;
    stats.avgSpeed = durationMinutes > 0 ? stats.keystrokeCount / durationMinutes : 0;
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="max-w-4xl mx-auto space-y-8"
    >
      <div className="flex items-center justify-between">
        <button
          onClick={onBack}
          className="flex items-center gap-2 text-ink/40 hover:text-ink transition-colors group"
        >
          <ChevronLeft className="w-5 h-5 group-hover:-translate-x-1 transition-transform" />
          <span className="text-sm font-bold uppercase tracking-widest">Back to Dashboard</span>
        </button>
        <div className="flex items-center gap-2 text-ink/40">
          <Calendar className="w-4 h-4" />
          <span className="text-sm font-mono">{new Date(createdAt).toLocaleString()}</span>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        <div className="md:col-span-2 space-y-8">
          <div className="bg-white p-8 rounded-3xl border border-ink/10 shadow-sm">
            <div className="flex items-center justify-between mb-8">
              <h2 className="text-2xl font-serif italic text-ink">Authenticity Analysis</h2>
              <div className={`px-6 py-2 rounded-full font-bold text-lg ${
                analysisResult?.confidenceScore > 80 ? 'bg-green-100 text-green-700' :
                analysisResult?.confidenceScore > 50 ? 'bg-yellow-100 text-yellow-700' :
                'bg-red-100 text-red-700'
              }`}>
                {analysisResult?.confidenceScore}% Human Confidence
              </div>
            </div>

            <div className="p-6 bg-ink/5 rounded-2xl border border-ink/10 mb-8">
              <h3 className="text-xs font-bold uppercase tracking-widest text-ink/40 mb-3">AI Assessment Summary</h3>
              <p className="text-ink leading-relaxed text-lg">{analysisResult?.summary}</p>
            </div>

            {analysisResult?.suspiciousPatterns?.length > 0 && (
              <div>
                <h3 className="text-xs font-bold uppercase tracking-widest text-ink/40 mb-4">Detected Anomalies</h3>
                <div className="grid gap-3">
                  {analysisResult.suspiciousPatterns.map((pattern: string, i: number) => (
                    <div key={i} className="flex items-start gap-4 p-4 bg-red-50 rounded-xl border border-red-100 text-red-700">
                      <AlertCircle className="w-5 h-5 mt-0.5 flex-shrink-0" />
                      <span className="text-sm font-medium">{pattern}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          <div className="bg-white p-8 rounded-3xl border border-ink/10 shadow-sm">
            <h3 className="text-xs font-bold uppercase tracking-widest text-ink/40 mb-6">Original Text</h3>
            <div className="p-6 bg-ink/[0.02] rounded-2xl border border-ink/5 font-serif text-lg leading-relaxed text-ink/80 whitespace-pre-wrap">
              {text}
            </div>
          </div>
        </div>

        <div className="space-y-6">
          <div className="bg-white p-6 rounded-3xl border border-ink/10 shadow-sm">
            <h3 className="text-xs font-bold uppercase tracking-widest text-ink/40 mb-6">Writing Metrics</h3>
            <div className="space-y-4">
              <div className="flex items-center justify-between p-4 bg-ink/5 rounded-2xl">
                <div className="flex items-center gap-3 text-ink/60">
                  <Type className="w-4 h-4" />
                  <span className="text-sm font-medium">Words</span>
                </div>
                <span className="font-mono font-bold text-ink">{stats.wordCount}</span>
              </div>
              <div className="flex items-center justify-between p-4 bg-ink/5 rounded-2xl">
                <div className="flex items-center gap-3 text-ink/60">
                  <Activity className="w-4 h-4" />
                  <span className="text-sm font-medium">Typing Speed</span>
                </div>
                <span className="font-mono font-bold text-ink">{stats.avgSpeed.toFixed(0)} CPM</span>
              </div>
              <div className="flex items-center justify-between p-4 bg-ink/5 rounded-2xl">
                <div className="flex items-center gap-3 text-ink/60">
                  <MousePointer className="w-4 h-4" />
                  <span className="text-sm font-medium">Paste Events</span>
                </div>
                <span className="font-mono font-bold text-ink">{stats.pasteCount}</span>
              </div>
              <div className="flex items-center justify-between p-4 bg-ink/5 rounded-2xl">
                <div className="flex items-center gap-3 text-ink/60">
                  <Clock className="w-4 h-4" />
                  <span className="text-sm font-medium">Keystrokes</span>
                </div>
                <span className="font-mono font-bold text-ink">{stats.keystrokeCount}</span>
              </div>
            </div>
          </div>

          <div className="bg-ink p-6 rounded-3xl border border-white/10 shadow-xl text-white">
            <div className="flex items-center gap-3 mb-4">
              <ShieldCheck className="w-6 h-6 text-green-400" />
              <h3 className="text-sm font-bold uppercase tracking-widest">Verification Status</h3>
            </div>
            <p className="text-xs text-white/60 leading-relaxed mb-6">
              This report is cryptographically linked to the writing session metadata captured in real-time.
            </p>
            <div className="p-4 bg-white/5 rounded-2xl border border-white/10 font-mono text-[10px] break-all opacity-40">
              ID: {session.id}
            </div>
          </div>
        </div>
      </div>
    </motion.div>
  );
}
