import React, { useState } from 'react';
import { storage, User } from '../lib/storage';
import { toast } from 'sonner';
import { LogIn, LogOut, ShieldCheck, Mail, User as UserIcon, ArrowRight, Loader2, Ghost } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export default function Auth({ user, onAuthChange }: { user: User | null, onAuthChange: () => void }) {
  const [loading, setLoading] = useState(false);
  const [mode, setMode] = useState<'options' | 'email' | 'signup'>('options');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const handleEmailAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !password) return;
    setLoading(true);
    
    // Mock authentication
    setTimeout(() => {
      const newUser: User = {
        uid: crypto.randomUUID(),
        email: email,
        displayName: email.split('@')[0],
        isAnonymous: false
      };
      storage.setUser(newUser);
      toast.success(mode === 'signup' ? 'Account created successfully!' : 'Signed in successfully!');
      setLoading(false);
      onAuthChange();
    }, 1000);
  };

  const handleGuestSignIn = async () => {
    setLoading(true);
    setTimeout(() => {
      const newUser: User = {
        uid: 'guest-' + crypto.randomUUID(),
        email: 'guest@vinotes.local',
        displayName: 'Guest User',
        isAnonymous: true
      };
      storage.setUser(newUser);
      toast.success('Continuing as Guest...');
      setLoading(false);
      onAuthChange();
    }, 800);
  };

  const handleSignOut = () => {
    storage.setUser(null);
    toast.success('Signed out successfully.');
    onAuthChange();
  };

  if (user) {
    return (
      <div className="flex items-center gap-4">
        <div className="flex flex-col items-end">
          <span className="text-sm font-medium text-ink">
            {user.displayName}
          </span>
          <span className="text-xs text-ink/60">
            {user.isAnonymous ? 'Temporary Access' : user.email}
          </span>
        </div>
        <button
          onClick={handleSignOut}
          className="p-2 rounded-full hover:bg-ink/5 transition-colors"
          title="Sign Out"
        >
          <LogOut className="w-5 h-5 text-ink/60" />
        </button>
      </div>
    );
  }

  return (
    <div className="w-full max-w-md p-8 bg-white rounded-3xl shadow-sm border border-ink/10">
      <div className="flex flex-col items-center mb-8">
        <div className="w-16 h-16 bg-ink rounded-2xl flex items-center justify-center mb-6">
          <ShieldCheck className="w-8 h-8 text-white" />
        </div>
        <h2 className="text-2xl font-serif italic text-ink">Vi-Notes Access</h2>
        <p className="text-ink/60 text-center text-sm mt-2">
          Choose your preferred verification method
        </p>
      </div>

      <AnimatePresence mode="wait">
        {mode === 'options' ? (
          <motion.div
            key="options"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="space-y-4"
          >
            <button
              onClick={handleGuestSignIn}
              disabled={loading}
              className="w-full flex items-center justify-center gap-3 px-6 py-4 bg-ink text-white rounded-2xl font-bold uppercase tracking-widest hover:bg-ink/90 transition-all shadow-lg shadow-ink/10"
            >
              {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : <Ghost className="w-5 h-5" />}
              Continue as Guest
            </button>

            <div className="relative py-4">
              <div className="absolute inset-0 flex items-center"><div className="w-full border-t border-ink/5"></div></div>
              <div className="relative flex justify-center text-xs uppercase font-bold tracking-widest text-ink/20 bg-white px-4">Or sign in with</div>
            </div>

            <div className="grid grid-cols-1 gap-4">
              <button
                onClick={() => setMode('email')}
                className="flex items-center justify-center gap-2 px-4 py-4 bg-white border border-ink/10 text-ink rounded-2xl font-bold uppercase tracking-[0.05em] text-[10px] hover:bg-ink/5 transition-all"
              >
                <Mail className="w-4 h-4" />
                Email Address
              </button>
            </div>
            
            <p className="text-[10px] text-center text-ink/30 uppercase font-bold tracking-widest mt-4">
              Use Guest mode for instant access without an account
            </p>
          </motion.div>
        ) : (
          <motion.form
            key="email"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            onSubmit={handleEmailAuth}
            className="space-y-4"
          >
            <div className="space-y-2">
              <label className="text-[10px] uppercase font-bold tracking-widest text-ink/40 ml-4">Email</label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="any@email.com"
                className="w-full px-6 py-4 bg-ink/5 rounded-2xl border border-transparent focus:border-ink/10 focus:bg-white outline-none transition-all font-mono text-sm"
                required
              />
              <p className="text-[9px] text-ink/30 uppercase font-bold tracking-widest ml-4">
                Tip: You can use any throwaway email for this project
              </p>
            </div>
            <div className="space-y-2">
              <label className="text-[10px] uppercase font-bold tracking-widest text-ink/40 ml-4">Password</label>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full px-6 py-4 bg-ink/5 rounded-2xl border border-transparent focus:border-ink/10 focus:bg-white outline-none transition-all font-mono text-sm"
                required
              />
            </div>
            
            <button
              type="submit"
              disabled={loading}
              className="w-full flex items-center justify-center gap-3 px-6 py-4 bg-ink text-white rounded-2xl font-bold uppercase tracking-widest hover:bg-ink/90 transition-all disabled:opacity-50"
            >
              {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : <ArrowRight className="w-5 h-5" />}
              {mode === 'signup' ? 'Create Account' : 'Sign In'}
            </button>

            <div className="flex items-center justify-between px-2">
              <button
                type="button"
                onClick={() => setMode(mode === 'email' ? 'signup' : 'email')}
                className="text-xs font-bold uppercase tracking-widest text-ink/40 hover:text-ink transition-colors"
              >
                {mode === 'email' ? 'Need an account?' : 'Already have one?'}
              </button>
              <button
                type="button"
                onClick={() => setMode('options')}
                className="text-xs font-bold uppercase tracking-widest text-ink/40 hover:text-ink transition-colors"
              >
                Back to options
              </button>
            </div>
          </motion.form>
        )}
      </AnimatePresence>
    </div>
  );
}
