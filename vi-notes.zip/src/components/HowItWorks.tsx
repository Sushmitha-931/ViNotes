import React from 'react';
import { ShieldCheck, Zap, Activity, Brain, Lock, MousePointer } from 'lucide-react';
import { motion } from 'motion/react';

export default function HowItWorks() {
  const steps = [
    {
      icon: <Activity className="w-6 h-6" />,
      title: "Biometric Capture",
      description: "As you type, we record the precise 'dwell time' (how long a key is held) and 'flight time' (time between keys). This creates a unique typing signature."
    },
    {
      icon: <MousePointer className="w-6 h-6" />,
      title: "Event Monitoring",
      description: "We monitor clipboard events to detect 'pasted' content, which is a common indicator of AI-generated text being moved into the editor."
    },
    {
      icon: <Brain className="w-6 h-6" />,
      title: "Linguistic Cross-Check",
      description: "Gemini 3.1 Pro analyzes the text's complexity and compares it against the captured typing rhythm to find inconsistencies."
    },
    {
      icon: <ShieldCheck className="w-6 h-6" />,
      title: "Authenticity Score",
      description: "A final confidence score is generated, certifying the content as 'Human-Authored' or flagging it as 'Potentially Synthetic'."
    }
  ];

  return (
    <div className="space-y-12 py-8">
      <div className="text-center max-w-2xl mx-auto">
        <h2 className="text-3xl font-serif italic mb-4">Project Overview</h2>
        <p className="text-ink/60">
          Vi-Notes is a proof-of-concept project designed to solve the "AI Plagiarism" problem 
          by verifying the physical act of writing in real-time.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {steps.map((step, i) => (
          <motion.div
            key={i}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.1 }}
            className="p-8 bg-white rounded-3xl border border-ink/10 shadow-sm hover:shadow-md transition-all"
          >
            <div className="w-12 h-12 bg-ink/5 rounded-2xl flex items-center justify-center mb-6 text-ink">
              {step.icon}
            </div>
            <h3 className="text-xl font-serif italic mb-3">{step.title}</h3>
            <p className="text-sm text-ink/60 leading-relaxed">{step.description}</p>
          </motion.div>
        ))}
      </div>

      <div className="bg-ink text-white p-10 rounded-[2.5rem] shadow-xl relative overflow-hidden">
        <div className="absolute top-0 right-0 p-8 opacity-10">
          <Zap className="w-32 h-32" />
        </div>
        <div className="relative z-10">
          <h3 className="text-2xl font-serif italic mb-6">Why this matters</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="space-y-2">
              <div className="text-xs font-bold uppercase tracking-widest text-white/40">For Education</div>
              <p className="text-sm text-white/70">Ensures students actually write their own essays instead of just prompting AI.</p>
            </div>
            <div className="space-y-2">
              <div className="text-xs font-bold uppercase tracking-widest text-white/40">For Journalism</div>
              <p className="text-sm text-white/70">Provides a 'Proof of Work' for original reporting and creative writing.</p>
            </div>
            <div className="space-y-2">
              <div className="text-xs font-bold uppercase tracking-widest text-white/40">For Legal</div>
              <p className="text-sm text-white/70">Creates a timestamped, biometric record of document creation.</p>
            </div>
          </div>
        </div>
      </div>

      <div className="flex items-center justify-center gap-4 py-8">
        <div className="flex items-center gap-2 text-ink/40">
          <Lock className="w-4 h-4" />
          <span className="text-[10px] font-bold uppercase tracking-widest">End-to-End Encrypted Metadata</span>
        </div>
        <div className="w-1 h-1 bg-ink/10 rounded-full" />
        <div className="flex items-center gap-2 text-ink/40">
          <ShieldCheck className="w-4 h-4" />
          <span className="text-[10px] font-bold uppercase tracking-widest">GDPR Compliant Biometrics</span>
        </div>
      </div>
    </div>
  );
}
